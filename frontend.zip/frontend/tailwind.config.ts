import type { Config } from "tailwindcss";
import { fontFamily } from "tailwindcss/defaultTheme";

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        background: "#F3EFE0", // Warm neutral, aged paper-like
        foreground: "#3E3B32", // Deep brown, vintage ink-like
        border: "#A08968", // Muted earthy brown
        accent: {
          DEFAULT: "#B27D42", // Warm terracotta accent
          foreground: "#3E3B32",
        },
        primary: {
          DEFAULT: "#D8A47F", // Soft, earthy peach
          foreground: "#3E3B32",
        },
        secondary: {
          DEFAULT: "#6C8C6B", // Muted moss green
          foreground: "#F3EFE0",
        },
        muted: {
          DEFAULT: "#A89F91", // Soft, organic taupe
          foreground: "#3E3B32",
        },
        button: {
          DEFAULT: "#FFD700", // High-contrast bright yellow CTA button
          foreground: "#3E3B32",
        },
        card: {
          DEFAULT: "#ECE5D8", // Vintage-inspired soft beige
          foreground: "#3E3B32",
        },
      },
      borderRadius: {
        lg: "16px",
        md: "12px",
        sm: "8px",
      },
      fontFamily: {
        sans: ["var(--font-sans)", ...fontFamily.sans],
        serif: ["Merriweather", "serif"], // Vintage, nature-inspired serif
      },
      keyframes: {
        "fade-in": {
          "0%": { opacity: "0", transform: "translateY(10px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "scale-in": {
          "0%": { transform: "scale(0.95)", opacity: "0" },
          "100%": { transform: "scale(1)", opacity: "1" },
        },
      },
      animation: {
        "fade-in": "fade-in 0.5s ease-out",
        "scale-in": "scale-in 0.3s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
