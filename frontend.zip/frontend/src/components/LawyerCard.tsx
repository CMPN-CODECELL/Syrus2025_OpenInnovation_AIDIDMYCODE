
import { Star, MapPin, Phone, Mail, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface LawyerProps {
  id: string;
  name: string;
  specialization: string[];
  location: string;
  rating: number;
  reviewCount: number;
  description: string;
  imageUrl: string;
  phone?: string;
  email?: string;
  website?: string;
  yearsOfExperience: number;
}

const LawyerCard = ({
  id,
  name,
  specialization,
  location,
  rating,
  reviewCount,
  description,
  imageUrl,
  phone,
  email,
  website,
  yearsOfExperience,
}: LawyerProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div 
      className="bg-card rounded-xl overflow-hidden border border-border transition-all duration-300 hover:shadow-lg animate-fade-in"
    >
      <div className="p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="relative w-20 h-20 rounded-full overflow-hidden bg-primary/10 flex-shrink-0">
            {imageUrl ? (
              <img
                src={imageUrl}
                alt={name}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-2xl font-bold text-primary">
                {name.charAt(0)}
              </div>
            )}
          </div>
          
          <div className="flex-1">
            <h3 className="text-xl font-bold">{name}</h3>
            <div className="flex flex-wrap gap-1 mt-1 mb-2">
              {specialization.map((spec, index) => (
                <Badge key={index} variant="secondary" className="font-medium">
                  {spec}
                </Badge>
              ))}
            </div>
            <div className="flex items-center text-sm text-muted-foreground">
              <MapPin className="w-4 h-4 mr-1" />
              <span>{location}</span>
              <span className="mx-2">•</span>
              <span>{yearsOfExperience} years experience</span>
            </div>
          </div>
          
          <div className="flex items-center mt-2 sm:mt-0">
            <div className="flex items-center">
              <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
              <span className="ml-1 font-medium">{rating}</span>
            </div>
            <span className="ml-1 text-sm text-muted-foreground">
              ({reviewCount} reviews)
            </span>
          </div>
        </div>
        
        <div className="mt-4">
          <p className={cn(
            "text-muted-foreground text-sm transition-all duration-300",
            isExpanded ? "" : "line-clamp-2"
          )}>
            {description}
          </p>
          {description.length > 150 && (
            <button
              className="text-primary text-sm font-medium mt-1 hover:underline focus:outline-none"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? "Show less" : "Read more"}
            </button>
          )}
        </div>
        
        <div className="flex flex-wrap justify-between items-center mt-6 gap-2">
          <div className="flex flex-wrap gap-3 text-sm">
            {phone && (
              <a 
                href={`tel:${phone}`}
                className="inline-flex items-center text-muted-foreground hover:text-primary transition-colors"
              >
                <Phone className="w-4 h-4 mr-1" />
                <span className="hidden sm:inline">{phone}</span>
              </a>
            )}
            
            {email && (
              <a 
                href={`mailto:${email}`}
                className="inline-flex items-center text-muted-foreground hover:text-primary transition-colors"
              >
                <Mail className="w-4 h-4 mr-1" />
                <span className="hidden sm:inline">{email}</span>
              </a>
            )}
            
            {website && (
              <a 
                href={website}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-muted-foreground hover:text-primary transition-colors"
              >
                <ExternalLink className="w-4 h-4 mr-1" />
                <span className="hidden sm:inline">Website</span>
              </a>
            )}
          </div>
          
          <Button className="ml-auto">
            Request Consultation
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LawyerCard;
