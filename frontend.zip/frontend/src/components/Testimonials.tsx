
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TestimonialsProps {
  className?: string;
}

const testimonials = [
  {
    id: 1,
    quote: "JustFair helped me navigate a complex tenant-landlord dispute. The platform connected me with an amazing lawyer who took my case pro bono. I couldn't be more grateful.",
    author: "Sarah Johnson",
    position: "Small Business Owner",
    rating: 5,
  },
  {
    id: 2,
    quote: "As someone who couldn't afford traditional legal representation, JustFair was a lifesaver. Their AI guidance initially pointed me in the right direction, and then I found an affordable attorney through their network.",
    author: "Michael Chen",
    position: "Graphic Designer",
    rating: 5,
  },
  {
    id: 3,
    quote: "The case submission process was incredibly straightforward. Within days, I had multiple qualified attorneys reaching out to help with my employment discrimination case.",
    author: "Priya Patel",
    position: "Healthcare Worker",
    rating: 4,
  },
  {
    id: 4,
    quote: "JustFair's platform is intuitive and user-friendly. I used their chatbot to understand my rights in a divorce proceeding before talking to a lawyer. It saved me time and money.",
    author: "David Rodriguez",
    position: "Teacher",
    rating: 5,
  },
];

const Testimonials = ({ className }: TestimonialsProps) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [autoplay, setAutoplay] = useState(true);

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  useEffect(() => {
    if (!autoplay) return;

    const interval = setInterval(() => {
      nextTestimonial();
    }, 6000);

    return () => clearInterval(interval);
  }, [autoplay, activeIndex]);

  return (
    <section className={cn("py-20 bg-justfair-gray", className)}>
      <div className="container px-4 sm:px-6 lg:px-8 mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block">
            <div className="px-3 py-1 rounded-full bg-primary/10 text-primary font-medium text-sm mb-6">
              Success Stories
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">What Our Users Say</h2>
          <p className="text-lg text-muted-foreground">
            Real people, real results. See how JustFair is making legal assistance accessible for everyone.
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative">
          <div 
            className="relative overflow-hidden rounded-2xl bg-white p-8 md:p-12 shadow-sm"
            onMouseEnter={() => setAutoplay(false)}
            onMouseLeave={() => setAutoplay(true)}
          >
            <Quote className="absolute top-6 left-6 h-12 w-12 text-primary/10" />

            <div className="relative z-10">
              {testimonials.map((testimonial, index) => (
                <div
                  key={testimonial.id}
                  className={cn(
                    "transition-opacity duration-500",
                    index === activeIndex ? "opacity-100" : "opacity-0 absolute inset-0"
                  )}
                >
                  <blockquote className="text-xl md:text-2xl font-medium text-foreground mb-8">
                    "{testimonial.quote}"
                  </blockquote>
                  <div className="flex items-center">
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                      {testimonial.author.charAt(0)}
                    </div>
                    <div className="ml-4">
                      <div className="font-semibold">{testimonial.author}</div>
                      <div className="text-sm text-muted-foreground">{testimonial.position}</div>
                    </div>
                    <div className="ml-auto flex">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <svg
                          key={i}
                          className={cn(
                            "w-5 h-5",
                            i < testimonial.rating ? "text-amber-400" : "text-gray-300"
                          )}
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="absolute bottom-8 right-8 flex space-x-2">
              <Button
                variant="outline"
                size="icon"
                className="rounded-full"
                onClick={prevTestimonial}
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="rounded-full"
                onClick={nextTestimonial}
                aria-label="Next testimonial"
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <div className="flex justify-center mt-6">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={cn(
                  "w-2.5 h-2.5 rounded-full mx-1 transition-colors",
                  index === activeIndex ? "bg-primary" : "bg-primary/20"
                )}
                onClick={() => setActiveIndex(index)}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
