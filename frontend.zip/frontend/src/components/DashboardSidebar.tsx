
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger
} from "@/components/ui/sidebar";
import { 
  Home, 
  FileText, 
  Users, 
  MessageSquare, 
  Settings, 
  LogOut,
  Sun,
  Moon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const DashboardSidebar = () => {
  const location = useLocation();
  const [isDarkMode, setIsDarkMode] = useState(false);

  const navigationItems = [
    { 
      title: "Dashboard", 
      path: "/dashboard", 
      icon: Home 
    },
    { 
      title: "My Cases", 
      path: "/case-submission", 
      icon: FileText 
    },
    { 
      title: "Lawyer Directory", 
      path: "/lawyers", 
      icon: Users 
    },
    { 
      title: "AI Chatbot", 
      path: "/chatbot", 
      icon: MessageSquare 
    },
    { 
      title: "Settings", 
      path: "/settings", 
      icon: Settings 
    }
  ];

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    // Here you would implement actual dark mode toggle logic
  };

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <Link to="/" className="flex items-center space-x-2">
          <span className="text-2xl font-bold text-primary">JustFair</span>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigationItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={location.pathname === item.path}
                    tooltip={item.title}
                  >
                    <Link to={item.path} className="flex items-center gap-2">
                      <item.icon className="h-5 w-5" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Quick Services</SidebarGroupLabel>
          <SidebarGroupContent>
            <div className="grid grid-cols-2 gap-2 p-2">
              <Link to="/lawyers" className="group">
                <div className="rounded-lg overflow-hidden border border-border p-1 transition-all hover:border-primary hover:shadow-sm">
                  <div className="bg-primary/10 rounded-md p-3 flex items-center justify-center mb-2">
                    <img 
                      src="/public/lovable-uploads/88b1cea6-f81b-4615-9106-bbbad08d0a3c.png" 
                      alt="Lawyer" 
                      className="h-8 w-8 object-contain"
                    />
                  </div>
                  <p className="text-xs text-center font-medium group-hover:text-primary transition-colors">Lawyer Consultation</p>
                </div>
              </Link>
              
              <Link to="/case-submission" className="group">
                <div className="rounded-lg overflow-hidden border border-border p-1 transition-all hover:border-primary hover:shadow-sm">
                  <div className="bg-primary/10 rounded-md p-3 flex items-center justify-center mb-2">
                    <img 
                      src="/public/lovable-uploads/299506a5-1cd6-4d1e-9670-35697d05f367.png" 
                      alt="Case" 
                      className="h-8 w-8 object-contain"
                    />
                  </div>
                  <p className="text-xs text-center font-medium group-hover:text-primary transition-colors">Case Submission</p>
                </div>
              </Link>
              
              <Link to="/chatbot" className="group col-span-2">
                <div className="rounded-lg overflow-hidden border border-border p-1 transition-all hover:border-primary hover:shadow-sm">
                  <div className="bg-primary/10 rounded-md p-3 flex items-center justify-center mb-2">
                    <img 
                      src="/public/lovable-uploads/92b9000f-6d83-4545-8220-571d0bebc18a.png" 
                      alt="Chatbot" 
                      className="h-8 w-8 object-contain"
                    />
                  </div>
                  <p className="text-xs text-center font-medium group-hover:text-primary transition-colors">Legal AI Chatbot</p>
                </div>
              </Link>
            </div>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-border p-4">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-medium">Theme</span>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleDarkMode}
            className="h-8 w-8"
          >
            {isDarkMode ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>
        </div>
        
        <Button 
          variant="outline" 
          className="w-full justify-start"
          asChild
        >
          <Link to="/login">
            <LogOut className="mr-2 h-4 w-4" />
            Sign Out
          </Link>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
};

export default DashboardSidebar;
