
import { useState, useRef, useEffect } from "react";
import { Send, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  content: string;
  sender: "user" | "assistant";
  timestamp: Date;
}

interface ChatInterfaceProps {
  className?: string;
}

const ChatInterface = ({ className }: ChatInterfaceProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Hello! I'm your legal assistant. How can I help you today?",
      sender: "assistant",
      timestamp: new Date(),
    },
  ]);
  const [newMessage, setNewMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: newMessage,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setNewMessage("");
    setIsTyping(true);

    // Simulate AI response after a short delay
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: getAIResponse(newMessage),
        sender: "assistant",
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const getAIResponse = (message: string): string => {
    // This is a placeholder for actual AI integration
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes("hello") || lowerMessage.includes("hi")) {
      return "Hello there! How can I assist with your legal questions today?";
    } else if (lowerMessage.includes("divorce")) {
      return "Divorce laws vary by state. Generally, you'll need to file a petition with the family court in your county. Would you like information about the divorce process in your specific state?";
    } else if (lowerMessage.includes("tenant") || lowerMessage.includes("landlord")) {
      return "Landlord-tenant disputes are common. What specific issue are you facing? Is it related to repairs, eviction, security deposits, or something else?";
    } else if (lowerMessage.includes("will") || lowerMessage.includes("estate")) {
      return "Estate planning is important. A basic will should include your assets, beneficiaries, and an executor. Would you like information about creating a legally valid will in your state?";
    } else {
      return "Thank you for your question. To better assist you, could you provide more details about your legal situation? This will help me give you more relevant information.";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className={cn("flex flex-col h-full rounded-xl border border-border overflow-hidden bg-card", className)}>
      <div className="bg-primary p-4 text-primary-foreground">
        <h3 className="text-lg font-semibold flex items-center">
          <Bot className="w-5 h-5 mr-2" />
          Legal Assistant
        </h3>
        <p className="text-sm opacity-80">
          Ask any legal questions to get preliminary guidance
        </p>
      </div>

      <div className="flex-grow overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={cn(
              "flex w-full",
              message.sender === "user" ? "justify-end" : "justify-start"
            )}
          >
            <div
              className={cn(
                "max-w-[85%] rounded-xl px-4 py-3 break-words",
                message.sender === "user"
                  ? "bg-primary text-primary-foreground rounded-tr-none"
                  : "bg-muted text-foreground rounded-tl-none"
              )}
            >
              <div className="flex items-center mb-1">
                {message.sender === "assistant" ? (
                  <Bot className="w-4 h-4 mr-1.5" />
                ) : (
                  <User className="w-4 h-4 mr-1.5" />
                )}
                <span className="text-xs font-medium">
                  {message.sender === "user" ? "You" : "Legal Assistant"}
                </span>
                <span className="text-xs ml-auto">
                  {formatTime(message.timestamp)}
                </span>
              </div>
              <p className="text-sm whitespace-pre-wrap">{message.content}</p>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-muted rounded-xl px-4 py-3 rounded-tl-none max-w-[85%]">
              <div className="flex gap-1">
                <span className="w-2 h-2 rounded-full bg-foreground/60 animate-bounce"></span>
                <span
                  className="w-2 h-2 rounded-full bg-foreground/60 animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                ></span>
                <span
                  className="w-2 h-2 rounded-full bg-foreground/60 animate-bounce"
                  style={{ animationDelay: "0.4s" }}
                ></span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="p-3 border-t border-border">
        <div className="flex gap-2">
          <Textarea
            placeholder="Type your message here..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            className="min-h-10 resize-none"
            rows={1}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!newMessage.trim() || isTyping}
            size="icon"
            aria-label="Send message"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          This AI assistant provides general legal information, not legal advice.
          Always consult a qualified attorney for your specific situation.
        </p>
      </div>
    </div>
  );
};

export default ChatInterface;
