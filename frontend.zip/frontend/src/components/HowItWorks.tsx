
import { cn } from "@/lib/utils";
import { Scale, MessageSquare, FileText, User } from "lucide-react";

interface HowItWorksProps {
  className?: string;
}

const HowItWorks = ({ className }: HowItWorksProps) => {
  const steps = [
    {
      id: 1,
      title: "Create Your Account",
      description: "Sign up in minutes. Tell us about your legal needs so we can personalize your experience.",
      icon: User,
      color: "bg-blue-50 text-blue-500",
    },
    {
      id: 2,
      title: "Submit Your Case",
      description: "Fill out our simple form to describe your legal issue. Upload any relevant documents.",
      icon: FileText,
      color: "bg-green-50 text-green-500",
    },
    {
      id: 3,
      title: "Get AI-Powered Guidance",
      description: "Our intelligent legal assistant analyzes your case and provides preliminary guidance.",
      icon: MessageSquare,
      color: "bg-purple-50 text-purple-500",
    },
    {
      id: 4,
      title: "Connect with Legal Experts",
      description: "Get matched with qualified attorneys specializing in your particular legal area.",
      icon: Scale,
      color: "bg-amber-50 text-amber-500",
    },
  ];

  return (
    <section id="how-it-works" className={cn("py-20", className)}>
      <div className="container px-4 sm:px-6 lg:px-8 mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block">
            <div className="px-3 py-1 rounded-full bg-primary/10 text-primary font-medium text-sm mb-6">
              Simple Process
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">How JustFair Works</h2>
          <p className="text-lg text-muted-foreground">
            Our straightforward process makes finding legal help easier than ever before.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div 
              key={step.id} 
              className="relative flex flex-col items-center p-6 rounded-xl border border-border bg-card card-hover animate-fade-in" 
              style={{ animationDelay: `${0.1 * (index + 1)}s` }}
            >
              <div className={cn("w-14 h-14 rounded-full flex items-center justify-center mb-6", step.color)}>
                <step.icon className="w-7 h-7" />
              </div>
              <div className="absolute -top-3 left-6 px-3 py-1 bg-primary text-primary-foreground rounded-full text-xs font-bold">
                Step {step.id}
              </div>
              <h3 className="text-xl font-semibold mb-3 text-center">{step.title}</h3>
              <p className="text-center text-muted-foreground">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
