
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface HeroProps {
  className?: string;
}

const Hero = ({ className }: HeroProps) => {
  return (
    <section className={cn("relative min-h-[90vh] flex items-center", className)}>
      {/* Background with subtle pattern */}
      <div className="absolute inset-0 bg-gradient-to-b from-justfair-blue-light/20 to-background z-0" />
      
      {/* Decorative elements */}
      <div className="absolute top-20 right-20 w-64 h-64 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-20 left-20 w-96 h-96 rounded-full bg-justfair-blue/5 blur-3xl" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto text-center space-y-8 animate-fade-in">
          <div className="inline-block">
            <div className="px-3 py-1 rounded-full bg-primary/10 text-primary font-medium text-sm mb-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
              Justice Made Simple
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <span className="block text-foreground">Justice Made Accessible</span>
            <span className="block text-primary mt-2">& Fair for Everyone</span>
          </h1>
          
          <p className="mt-6 text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: "0.3s" }}>
            Connect with qualified legal professionals, get AI-powered assistance, and access the resources you need to navigate complex legal matters with confidence.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 pt-6 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <Link to="/signup">
              <Button size="lg" className="w-full sm:w-auto font-medium px-8 gap-2 group">
                Get Started
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
            <Link to="/lawyers">
              <Button size="lg" variant="outline" className="w-full sm:w-auto font-medium px-8">
                Find Legal Help
              </Button>
            </Link>
          </div>
          
          <div className="pt-12 animate-fade-in" style={{ animationDelay: "0.5s" }}>
            <p className="text-sm text-muted-foreground mb-4">Trusted by legal professionals nationwide</p>
            <div className="flex flex-wrap justify-center gap-8 items-center opacity-60">
              {/* Replace with actual partner logos */}
              <div className="text-xl font-bold text-gray-400">ACLU</div>
              <div className="text-xl font-bold text-gray-400">Legal Aid Society</div>
              <div className="text-xl font-bold text-gray-400">ABA</div>
              <div className="text-xl font-bold text-gray-400">NAACP</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
