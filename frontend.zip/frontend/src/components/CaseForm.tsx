
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { AlertCircle, Upload, CheckCircle2, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  title: z.string().min(5, {
    message: "Title must be at least 5 characters.",
  }),
  description: z.string().min(20, {
    message: "Description must be at least 20 characters.",
  }),
  category: z.string({
    required_error: "Please select a legal category.",
  }),
  urgency: z.string({
    required_error: "Please select an urgency level.",
  }),
});

type FormValues = z.infer<typeof formSchema>;

interface CaseFormProps {
  className?: string;
}

const CaseForm = ({ className }: CaseFormProps) => {
  const [files, setFiles] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      urgency: "",
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    console.log("Form submitted:", data);
    console.log("Files:", files);
    
    toast({
      title: "Case submitted successfully",
      description: "We'll connect you with a legal expert soon.",
      duration: 5000,
    });
    
    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles(prev => [...prev, ...newFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const categories = [
    { label: "Family Law", value: "family" },
    { label: "Immigration", value: "immigration" },
    { label: "Criminal Defense", value: "criminal" },
    { label: "Civil Rights", value: "civil-rights" },
    { label: "Personal Injury", value: "personal-injury" },
    { label: "Employment Law", value: "employment" },
    { label: "Landlord/Tenant", value: "housing" },
    { label: "Business Law", value: "business" },
    { label: "Intellectual Property", value: "ip" },
    { label: "Estate Planning", value: "estate" },
  ];

  const urgencyLevels = [
    { label: "Urgent (24-48 hours)", value: "urgent" },
    { label: "High (3-5 days)", value: "high" },
    { label: "Medium (1-2 weeks)", value: "medium" },
    { label: "Low (2+ weeks)", value: "low" },
  ];

  if (isSubmitted) {
    return (
      <div className={cn("max-w-2xl mx-auto py-12", className)}>
        <div className="text-center space-y-4 animate-fade-in">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600 mb-4">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold">Case Submitted Successfully!</h2>
          <p className="text-muted-foreground">
            Your case has been received. Our team will review your information and connect you with the right legal expert soon.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Case ID: <span className="font-mono font-medium">JF-{Math.floor(100000 + Math.random() * 900000)}</span>
          </p>
          <div className="pt-6">
            <Button onClick={() => setIsSubmitted(false)}>Submit Another Case</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("max-w-2xl mx-auto", className)}>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 animate-fade-in">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Case Title</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="Brief title describing your legal issue" 
                    {...field} 
                    className="h-12"
                  />
                </FormControl>
                <FormDescription>
                  Provide a clear title that summarizes your legal issue.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="category"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Legal Category</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Select a legal category" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormDescription>
                  Choose the category that best fits your legal issue.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="urgency"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Urgency Level</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Select urgency level" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {urgencyLevels.map((level) => (
                      <SelectItem key={level.value} value={level.value}>
                        {level.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormDescription>
                  This helps us prioritize your case appropriately.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Case Description</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Provide detailed information about your legal issue..."
                    className="min-h-32 resize-none"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  Include relevant details, dates, and context to help lawyers understand your situation.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-4">
            <div>
              <FormLabel htmlFor="documents">Supporting Documents</FormLabel>
              <div className="mt-1">
                <label
                  htmlFor="file-upload"
                  className="group relative flex justify-center px-6 py-10 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-secondary/50 transition-colors"
                >
                  <div className="space-y-2 text-center">
                    <Upload className="mx-auto h-12 w-12 text-muted-foreground group-hover:text-primary transition-colors" />
                    <div className="text-sm text-muted-foreground">
                      <span className="font-medium text-primary">
                        Click to upload
                      </span>{" "}
                      or drag and drop
                    </div>
                    <p className="text-xs text-muted-foreground">
                      PDF, DOCX, JPG, PNG up to 10MB each
                    </p>
                  </div>
                  <input
                    id="file-upload"
                    name="file-upload"
                    type="file"
                    className="sr-only"
                    multiple
                    onChange={handleFileChange}
                    accept=".pdf,.docx,.jpg,.jpeg,.png"
                  />
                </label>
              </div>
            </div>

            {files.length > 0 && (
              <div className="bg-secondary/50 rounded-lg p-4">
                <h4 className="font-medium mb-2 flex items-center">
                  <FileText className="w-4 h-4 mr-2" />
                  Uploaded Documents ({files.length})
                </h4>
                <ul className="space-y-2">
                  {files.map((file, index) => (
                    <li
                      key={index}
                      className="text-sm flex items-center justify-between bg-background rounded-md p-2"
                    >
                      <div className="flex items-center overflow-hidden">
                        <FileText className="w-4 h-4 mr-2 flex-shrink-0" />
                        <span className="truncate">{file.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(index)}
                        className="ml-2 h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                      >
                        &times;
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start">
            <AlertCircle className="w-5 h-5 text-amber-500 mr-3 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-amber-800">
              <p className="font-medium">Important Note</p>
              <p className="mt-1">
                By submitting this form, you acknowledge that this doesn't create an attorney-client relationship. Your information will be reviewed to determine if we can assist you.
              </p>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Submitting..." : "Submit Case"}
          </Button>
        </form>
      </Form>
    </div>
  );
};

export default CaseForm;
