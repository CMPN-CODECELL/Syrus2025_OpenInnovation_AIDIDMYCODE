import Layout from "@/components/Layout";
import Hero from "@/components/Hero";
import HowItWorks from "@/components/HowItWorks";
import Testimonials from "@/components/Testimonials";
import ChatInterface from "@/components/ChatInterface";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles, Briefcase, ShieldCheck, Scale } from "lucide-react";

const Index = () => {
  return (
    <Layout fullWidth>
      {/* Hero Section */}
      <Hero />

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-block">
              <div className="px-3 py-1 rounded-full bg-primary/10 text-primary font-medium text-sm mb-6">
                Why Choose JustFair
              </div>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Fair Legal Help For Everyone</h2>
            <p className="text-lg text-muted-foreground">
              We're making legal assistance accessible, affordable, and equitable for all people.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-card rounded-xl p-6 border border-border shadow-sm animate-fade-in card-hover" style={{ animationDelay: "0.1s" }}>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                <Sparkles className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">AI-Powered Insights</h3>
              <p className="text-muted-foreground">
                Get preliminary legal guidance from our advanced AI assistant before connecting with an attorney.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-card rounded-xl p-6 border border-border shadow-sm animate-fade-in card-hover" style={{ animationDelay: "0.2s" }}>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                <Briefcase className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Expert Attorneys</h3>
              <p className="text-muted-foreground">
                Connect with qualified lawyers who specialize in your specific legal needs and are committed to fair representation.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-card rounded-xl p-6 border border-border shadow-sm animate-fade-in card-hover" style={{ animationDelay: "0.3s" }}>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                <ShieldCheck className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Transparent Process</h3>
              <p className="text-muted-foreground">
                Our straightforward platform eliminates hidden fees and confusing legal jargon to keep you informed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <HowItWorks />

      {/* Chat Demo Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white to-justfair-blue-light/20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 animate-fade-in">
              <div className="inline-block">
                <div className="px-3 py-1 rounded-full bg-primary/10 text-primary font-medium text-sm mb-6">
                  Legal Assistance
                </div>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold">
                Get Immediate Legal Guidance from Our AI Assistant
              </h2>
              <p className="text-lg text-muted-foreground">
                Our intelligent chatbot provides preliminary legal information and helps determine if you need professional legal assistance. Try it out!
              </p>
              <ul className="space-y-3">
                {["Get answers to common legal questions", "Understand basic legal concepts and rights", "Determine if your situation requires an attorney", "Receive guidance on next steps"].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <Scale className="w-5 h-5 text-primary mr-2 mt-1" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <div className="pt-4">
                <Link to="/chatbot">
                  <Button className="gap-2 group">
                    Try Full Chatbot
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
              </div>
            </div>
            <div className="lg:max-w-md mx-auto animate-fade-in">
              <div className="rounded-xl overflow-hidden shadow-lg h-[500px] border border-border">
                <ChatInterface />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <Testimonials />

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-6 animate-fade-in">
            Ready to Get the Legal Help You Deserve?
          </h2>
          <p className="text-xl text-primary-foreground/90 mb-8 max-w-3xl mx-auto animate-fade-in" style={{ animationDelay: "0.1s" }}>
            Join thousands of people who have found fair and accessible legal assistance through our platform.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <Link to="/signup">
              <Button size="lg" variant="secondary" className="gap-2 group">
                Sign Up Now
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
            <Link to="/lawyers">
              <Button size="lg" variant="outline" className="text-primary-foreground border-primary-foreground/20 hover:bg-primary-foreground/10">
                Browse Lawyers
              </Button>
            </Link>
            <Link to="/dashboard">
              <Button size="lg" variant="secondary" className="gap-2 group">
                Dashboard
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
