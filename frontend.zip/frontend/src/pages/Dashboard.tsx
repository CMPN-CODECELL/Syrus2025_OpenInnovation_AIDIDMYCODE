
import { useState } from "react";
import Layout from "@/components/Layout";
import DashboardSidebar from "@/components/DashboardSidebar";
import { 
  SidebarProvider, 
  SidebarInset, 
  SidebarTrigger 
} from "@/components/ui/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Users, MessageSquare, Bell, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

const Dashboard = () => {
  // Mock data for recent cases
  const recentCases = [
    { id: 1, title: "Employment Discrimination Case", status: "In Progress", date: "2023-09-15" },
    { id: 2, title: "Landlord-Tenant Dispute", status: "Pending Review", date: "2023-09-10" },
    { id: 3, title: "Contract Breach Resolution", status: "Assigned to Lawyer", date: "2023-09-05" },
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <DashboardSidebar />
        
        <SidebarInset>
          <div className="p-4 sm:p-6 lg:p-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold">Dashboard</h1>
                <p className="text-muted-foreground">Welcome to your JustFair dashboard</p>
              </div>
              
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] font-medium text-primary-foreground flex items-center justify-center">
                    3
                  </span>
                </Button>
                <SidebarTrigger className="md:hidden" />
              </div>
            </div>
            
            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Card className="group hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="bg-primary/10 rounded-full p-4 mb-4">
                    <img 
                      src="/public/lovable-uploads/299506a5-1cd6-4d1e-9670-35697d05f367.png" 
                      alt="File a Case" 
                      className="h-12 w-12 object-contain"
                    />
                  </div>
                  <h3 className="font-medium mb-2">Submit a New Case</h3>
                  <p className="text-sm text-muted-foreground mb-4">File details about your legal issue</p>
                  <Button asChild className="group-hover:bg-primary/90">
                    <Link to="/case-submission">
                      <Plus className="mr-2 h-4 w-4" />
                      New Case
                    </Link>
                  </Button>
                </CardContent>
              </Card>
              
              <Card className="group hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="bg-primary/10 rounded-full p-4 mb-4">
                    <img 
                      src="/public/lovable-uploads/88b1cea6-f81b-4615-9106-bbbad08d0a3c.png" 
                      alt="Find a Lawyer" 
                      className="h-12 w-12 object-contain"
                    />
                  </div>
                  <h3 className="font-medium mb-2">Find a Lawyer</h3>
                  <p className="text-sm text-muted-foreground mb-4">Browse qualified legal professionals</p>
                  <Button asChild variant="outline" className="group-hover:border-primary group-hover:text-primary">
                    <Link to="/lawyers">Browse Lawyers</Link>
                  </Button>
                </CardContent>
              </Card>
              
              <Card className="group hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="bg-primary/10 rounded-full p-4 mb-4">
                    <img 
                      src="/public/lovable-uploads/92b9000f-6d83-4545-8220-571d0bebc18a.png" 
                      alt="AI Legal Assistant" 
                      className="h-12 w-12 object-contain"
                    />
                  </div>
                  <h3 className="font-medium mb-2">AI Legal Assistant</h3>
                  <p className="text-sm text-muted-foreground mb-4">Get instant answers to legal questions</p>
                  <Button asChild variant="outline" className="group-hover:border-primary group-hover:text-primary">
                    <Link to="/chatbot">Chat Now</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
            
            {/* Recent Cases */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Cases</CardTitle>
                <CardDescription>
                  Your most recent legal case submissions and their status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentCases.map((c) => (
                    <div key={c.id} className="flex items-center justify-between border-b pb-4 last:border-0">
                      <div>
                        <h4 className="font-medium">{c.title}</h4>
                        <div className="flex items-center gap-4 mt-1">
                          <span className="text-sm text-muted-foreground">
                            Submitted: {new Date(c.date).toLocaleDateString()}
                          </span>
                          <div 
                            className={cn(
                              "px-2 py-1 rounded-full text-xs font-medium",
                              c.status === "In Progress" ? "bg-amber-100 text-amber-700" :
                              c.status === "Pending Review" ? "bg-blue-100 text-blue-700" :
                              "bg-green-100 text-green-700"
                            )}
                          >
                            {c.status}
                          </div>
                        </div>
                      </div>
                      <Button size="sm" variant="ghost">View Details</Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default Dashboard;
