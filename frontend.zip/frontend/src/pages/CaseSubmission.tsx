
import CaseForm from "@/components/CaseForm";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import DashboardSidebar from "@/components/DashboardSidebar";
import { 
  SidebarProvider, 
  SidebarInset, 
  SidebarTrigger 
} from "@/components/ui/sidebar";

const CaseSubmission = () => {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <DashboardSidebar />
        
        <SidebarInset>
          <div className="p-4 sm:p-6 lg:p-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <Link to="/dashboard" className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Dashboard
                </Link>
              </div>
              
              <SidebarTrigger className="md:hidden" />
            </div>
            
            <div className="text-center max-w-3xl mx-auto mt-8 mb-12">
              <h1 className="text-3xl font-bold mb-4">Submit Your Case</h1>
              <p className="text-muted-foreground">
                Fill out the form below with details about your legal issue. Our team will review your case and match you with appropriate legal assistance.
              </p>
            </div>
            
            <CaseForm />
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default CaseSubmission;
