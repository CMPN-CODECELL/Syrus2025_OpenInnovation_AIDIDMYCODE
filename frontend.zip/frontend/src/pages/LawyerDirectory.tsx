
import { useState, useEffect } from "react";
import { Search, Filter, X, MapPin, ArrowUpDown, Scale } from "lucide-react";
import Layout from "@/components/Layout";
import LawyerCard from "@/components/LawyerCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Sample data
const lawyersData = [
  {
    id: "1",
    name: "Jennifer Anderson",
    specialization: ["Family Law", "Divorce"],
    location: "New York, NY",
    rating: 4.9,
    reviewCount: 127,
    description:
      "Jennifer specializes in family law with over 15 years of experience in divorce, child custody, and spousal support cases. She is known for her compassionate approach and strong advocacy for her clients.",
    imageUrl: "",
    phone: "212-555-0123",
    email: "jennifer@example.com",
    website: "https://example.com",
    yearsOfExperience: 15,
  },
  {
    id: "2",
    name: "Michael Rodriguez",
    specialization: ["Criminal Defense", "DUI"],
    location: "Los Angeles, CA",
    rating: 4.7,
    reviewCount: 93,
    description:
      "Former prosecutor with extensive courtroom experience in criminal defense cases. Michael works tirelessly to defend the rights of those accused of crimes, from misdemeanors to serious felony charges.",
    imageUrl: "",
    phone: "323-555-0187",
    email: "michael@example.com",
    website: "https://example.com",
    yearsOfExperience: 12,
  },
  {
    id: "3",
    name: "Sarah Johnson",
    specialization: ["Immigration", "Asylum"],
    location: "Chicago, IL",
    rating: 4.8,
    reviewCount: 75,
    description:
      "Dedicated immigration attorney helping individuals and families navigate the complex U.S. immigration system. Sarah specializes in family-based immigration, deportation defense, and asylum cases.",
    imageUrl: "",
    phone: "312-555-0439",
    email: "sarah@example.com",
    website: "https://example.com",
    yearsOfExperience: 8,
  },
  {
    id: "4",
    name: "David Chen",
    specialization: ["Employment Law", "Workplace Discrimination"],
    location: "San Francisco, CA",
    rating: 4.6,
    reviewCount: 88,
    description:
      "Advocate for employee rights with expertise in workplace discrimination, wrongful termination, and harassment cases. David has successfully represented clients against some of the largest corporations in California.",
    imageUrl: "",
    phone: "415-555-0299",
    email: "david@example.com",
    website: "https://example.com",
    yearsOfExperience: 10,
  },
  {
    id: "5",
    name: "Maria Gonzalez",
    specialization: ["Personal Injury", "Medical Malpractice"],
    location: "Miami, FL",
    rating: 4.9,
    reviewCount: 142,
    description:
      "Award-winning personal injury attorney specializing in complex medical malpractice and serious injury cases. Maria has recovered millions of dollars in settlements for her clients over her distinguished career.",
    imageUrl: "",
    phone: "305-555-0512",
    email: "maria@example.com",
    website: "https://example.com",
    yearsOfExperience: 18,
  },
];

const specializations = [
  "Family Law",
  "Criminal Defense",
  "Immigration",
  "Employment Law",
  "Personal Injury",
  "Real Estate",
  "Intellectual Property",
  "Tax Law",
  "Bankruptcy",
  "Estate Planning",
  "Corporate Law",
  "Civil Rights",
  "Environmental Law",
  "Healthcare Law",
  "Divorce",
  "DUI",
  "Asylum",
  "Workplace Discrimination",
  "Medical Malpractice",
];

const locations = [
  "New York, NY",
  "Los Angeles, CA",
  "Chicago, IL",
  "San Francisco, CA",
  "Miami, FL",
  "Houston, TX",
  "Boston, MA",
  "Philadelphia, PA",
  "Denver, CO",
  "Seattle, WA",
];

const LawyerDirectory = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSpecializations, setSelectedSpecializations] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [minExperience, setMinExperience] = useState(0);
  const [minRating, setMinRating] = useState(0);
  const [lawyers, setLawyers] = useState(lawyersData);
  const [filteredLawyers, setFilteredLawyers] = useState(lawyersData);
  const [sortOption, setSortOption] = useState<string>("rating_desc");
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  useEffect(() => {
    let results = lawyers;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      results = results.filter(
        (lawyer) =>
          lawyer.name.toLowerCase().includes(query) ||
          lawyer.specialization.some((spec) => spec.toLowerCase().includes(query)) ||
          lawyer.location.toLowerCase().includes(query) ||
          lawyer.description.toLowerCase().includes(query)
      );
    }

    if (selectedSpecializations.length > 0) {
      results = results.filter((lawyer) =>
        lawyer.specialization.some((spec) =>
          selectedSpecializations.includes(spec)
        )
      );
    }

    if (selectedLocations.length > 0) {
      results = results.filter((lawyer) =>
        selectedLocations.includes(lawyer.location)
      );
    }

    if (minExperience > 0) {
      results = results.filter(
        (lawyer) => lawyer.yearsOfExperience >= minExperience
      );
    }

    if (minRating > 0) {
      results = results.filter((lawyer) => lawyer.rating >= minRating);
    }

    if (sortOption === "rating_desc") {
      results = [...results].sort((a, b) => b.rating - a.rating);
    } else if (sortOption === "rating_asc") {
      results = [...results].sort((a, b) => a.rating - b.rating);
    } else if (sortOption === "experience_desc") {
      results = [...results].sort(
        (a, b) => b.yearsOfExperience - a.yearsOfExperience
      );
    } else if (sortOption === "experience_asc") {
      results = [...results].sort(
        (a, b) => a.yearsOfExperience - b.yearsOfExperience
      );
    } else if (sortOption === "name_asc") {
      results = [...results].sort((a, b) => a.name.localeCompare(b.name));
    }

    setFilteredLawyers(results);
  }, [
    lawyers,
    searchQuery,
    selectedSpecializations,
    selectedLocations,
    minExperience,
    minRating,
    sortOption,
  ]);

  const toggleSpecialization = (specialization: string) => {
    setSelectedSpecializations((prev) =>
      prev.includes(specialization)
        ? prev.filter((spec) => spec !== specialization)
        : [...prev, specialization]
    );
  };

  const toggleLocation = (location: string) => {
    setSelectedLocations((prev) =>
      prev.includes(location)
        ? prev.filter((loc) => loc !== location)
        : [...prev, location]
    );
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedSpecializations([]);
    setSelectedLocations([]);
    setMinExperience(0);
    setMinRating(0);
  };

  const handleSortChange = (option: string) => {
    setSortOption(option);
  };

  const removeSpecialization = (specialization: string) => {
    setSelectedSpecializations((prev) =>
      prev.filter((spec) => spec !== specialization)
    );
  };

  const removeLocation = (location: string) => {
    setSelectedLocations((prev) => prev.filter((loc) => loc !== location));
  };

  const activeFilterCount =
    selectedSpecializations.length +
    selectedLocations.length +
    (minExperience > 0 ? 1 : 0) +
    (minRating > 0 ? 1 : 0);

  return (
    <Layout>
      <div className="py-12 animate-fade-in">
        <div className="mb-12 text-center">
          <h1 className="text-3xl font-bold mb-3">Find Legal Experts</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Connect with qualified attorneys specializing in various legal fields.
            Search and filter to find the right lawyer for your specific needs.
          </p>
          <div className="mt-6 w-48 h-48 mx-auto">
            <img 
              src="/public/lovable-uploads/88b1cea6-f81b-4615-9106-bbbad08d0a3c.png" 
              alt="Find a Lawyer" 
              className="w-full h-full object-contain"
            />
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          <div className="hidden lg:block w-64 flex-shrink-0">
            <div className="bg-card rounded-lg border border-border p-5 sticky top-24">
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-semibold">Filters</h2>
                {activeFilterCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearFilters}
                    className="h-8 text-xs"
                  >
                    Clear All
                  </Button>
                )}
              </div>

              <div className="space-y-6">
                <Accordion type="single" collapsible defaultValue="specialization">
                  <AccordionItem value="specialization" className="border-b-0">
                    <AccordionTrigger className="py-3 text-sm">
                      Legal Specialization
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                        {specializations.map((specialization) => (
                          <div
                            key={specialization}
                            className="flex items-center space-x-2"
                          >
                            <Checkbox
                              id={`spec-${specialization}`}
                              checked={selectedSpecializations.includes(
                                specialization
                              )}
                              onCheckedChange={() =>
                                toggleSpecialization(specialization)
                              }
                            />
                            <label
                              htmlFor={`spec-${specialization}`}
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {specialization}
                            </label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>

                <Accordion type="single" collapsible defaultValue="location">
                  <AccordionItem value="location" className="border-b-0">
                    <AccordionTrigger className="py-3 text-sm">
                      Location
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                        {locations.map((location) => (
                          <div
                            key={location}
                            className="flex items-center space-x-2"
                          >
                            <Checkbox
                              id={`loc-${location}`}
                              checked={selectedLocations.includes(location)}
                              onCheckedChange={() => toggleLocation(location)}
                            />
                            <label
                              htmlFor={`loc-${location}`}
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {location}
                            </label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>

                <div className="space-y-3 py-3 border-t border-border">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-medium">
                      Min. Years of Experience
                    </h3>
                    <span className="text-sm">{minExperience}+</span>
                  </div>
                  <Slider
                    value={[minExperience]}
                    min={0}
                    max={20}
                    step={1}
                    onValueChange={(value) => setMinExperience(value[0])}
                  />
                </div>

                <div className="space-y-3 py-3 border-t border-border">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-medium">Min. Rating</h3>
                    <div className="flex items-center">
                      <span className="text-sm mr-1">{minRating.toFixed(1)}</span>
                      <svg
                        className="w-4 h-4 text-amber-400 fill-amber-400"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    </div>
                  </div>
                  <Slider
                    value={[minRating]}
                    min={0}
                    max={5}
                    step={0.1}
                    onValueChange={(value) => setMinRating(value[0])}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search by name, specialization, or location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12"
                />
                {searchQuery && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-1 top-1 h-10 w-10 p-0"
                    onClick={() => setSearchQuery("")}
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Clear search</span>
                  </Button>
                )}
              </div>

              <div className="flex gap-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="h-12 gap-1">
                      <ArrowUpDown className="h-4 w-4" />
                      Sort
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem
                      onClick={() => handleSortChange("rating_desc")}
                    >
                      Highest Rated
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => handleSortChange("experience_desc")}
                    >
                      Most Experienced
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => handleSortChange("name_asc")}
                    >
                      Name (A-Z)
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <Sheet
                  open={isMobileFilterOpen}
                  onOpenChange={setIsMobileFilterOpen}
                >
                  <SheetTrigger asChild>
                    <Button
                      variant="outline"
                      className="h-12 lg:hidden gap-1"
                      onClick={() => setIsMobileFilterOpen(true)}
                    >
                      <Filter className="h-4 w-4" />
                      Filters
                      {activeFilterCount > 0 && (
                        <span className="ml-1 bg-primary text-primary-foreground rounded-full px-1.5 py-0.5 text-xs">
                          {activeFilterCount}
                        </span>
                      )}
                    </Button>
                  </SheetTrigger>
                  <SheetContent className="w-full sm:max-w-md overflow-y-auto">
                    <SheetHeader>
                      <SheetTitle>Filters</SheetTitle>
                    </SheetHeader>
                    <div className="py-4">
                      <div className="space-y-6">
                        <Accordion
                          type="single"
                          collapsible
                          defaultValue="specialization"
                        >
                          <AccordionItem value="specialization" className="border-b">
                            <AccordionTrigger className="py-3">
                              Legal Specialization
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                                {specializations.map((specialization) => (
                                  <div
                                    key={specialization}
                                    className="flex items-center space-x-2"
                                  >
                                    <Checkbox
                                      id={`mobile-spec-${specialization}`}
                                      checked={selectedSpecializations.includes(
                                        specialization
                                      )}
                                      onCheckedChange={() =>
                                        toggleSpecialization(specialization)
                                      }
                                    />
                                    <label
                                      htmlFor={`mobile-spec-${specialization}`}
                                      className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                    >
                                      {specialization}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        </Accordion>

                        <Accordion type="single" collapsible defaultValue="location">
                          <AccordionItem value="location" className="border-b">
                            <AccordionTrigger className="py-3">
                              Location
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                                {locations.map((location) => (
                                  <div
                                    key={location}
                                    className="flex items-center space-x-2"
                                  >
                                    <Checkbox
                                      id={`mobile-loc-${location}`}
                                      checked={selectedLocations.includes(location)}
                                      onCheckedChange={() => toggleLocation(location)}
                                    />
                                    <label
                                      htmlFor={`mobile-loc-${location}`}
                                      className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                    >
                                      {location}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        </Accordion>

                        <div className="space-y-3 py-3 border-b">
                          <div className="flex justify-between items-center">
                            <h3 className="text-sm font-medium">
                              Min. Years of Experience
                            </h3>
                            <span className="text-sm">{minExperience}+</span>
                          </div>
                          <Slider
                            value={[minExperience]}
                            min={0}
                            max={20}
                            step={1}
                            onValueChange={(value) => setMinExperience(value[0])}
                          />
                        </div>

                        <div className="space-y-3 py-3 border-b">
                          <div className="flex justify-between items-center">
                            <h3 className="text-sm font-medium">Min. Rating</h3>
                            <div className="flex items-center">
                              <span className="text-sm mr-1">
                                {minRating.toFixed(1)}
                              </span>
                              <svg
                                className="w-4 h-4 text-amber-400 fill-amber-400"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                            </div>
                          </div>
                          <Slider
                            value={[minRating]}
                            min={0}
                            max={5}
                            step={0.1}
                            onValueChange={(value) => setMinRating(value[0])}
                          />
                        </div>
                      </div>

                      <div className="flex gap-3 mt-6">
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={clearFilters}
                        >
                          Clear All
                        </Button>
                        <Button
                          className="flex-1"
                          onClick={() => setIsMobileFilterOpen(false)}
                        >
                          See Results
                        </Button>
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
              </div>
            </div>

            <div className="mb-6">
              <p className="text-sm text-muted-foreground">
                Showing {filteredLawyers.length} {filteredLawyers.length === 1 ? "result" : "results"}
              </p>
            </div>

            {filteredLawyers.length > 0 ? (
              <div className="space-y-6">
                {filteredLawyers.map((lawyer) => (
                  <LawyerCard key={lawyer.id} {...lawyer} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-muted/30 rounded-lg border border-dashed">
                <Scale className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No lawyers found</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  We couldn't find any lawyers matching your search criteria. Try
                  adjusting your filters or search query.
                </p>
                <Button onClick={clearFilters}>Clear All Filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default LawyerDirectory;
