
import Layout from "@/components/Layout";
import ChatInterface from "@/components/ChatInterface";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { FileText, ArrowRight, HelpCircle } from "lucide-react";

const Chatbot = () => {
  return (
    <Layout>
      <div className="py-12">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Chat Interface */}
            <div className="lg:col-span-2 order-2 lg:order-1">
              <div className="h-[700px] animate-fade-in">
                <ChatInterface />
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1 order-1 lg:order-2">
              <div className="space-y-6">
                <div className="bg-card rounded-xl border border-border p-6 animate-fade-in">
                  <div className="flex justify-center mb-4">
                    <img 
                      src="/public/lovable-uploads/92b9000f-6d83-4545-8220-571d0bebc18a.png" 
                      alt="AI Legal Assistant" 
                      className="w-24 h-24 object-contain"
                    />
                  </div>
                  <h2 className="text-xl font-bold mb-3 text-center">Legal Assistant</h2>
                  <p className="text-muted-foreground mb-4">
                    Get preliminary legal guidance from our AI assistant. Ask questions about your legal situation and get help understanding your options.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-start gap-2">
                      <HelpCircle className="w-5 h-5 text-primary mt-0.5" />
                      <p className="text-sm">
                        This AI provides general legal information, not legal advice. Always consult a qualified attorney for your specific situation.
                      </p>
                    </div>
                    <Link to="/case-submission">
                      <Button className="w-full gap-2">
                        <FileText className="h-4 w-4" />
                        Submit a Case
                      </Button>
                    </Link>
                  </div>
                </div>

                <div className="bg-primary/5 rounded-xl border border-primary/10 p-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
                  <h3 className="font-semibold mb-2">Common Legal Questions</h3>
                  <ul className="space-y-2">
                    {[
                      "What should I do after a car accident?",
                      "How does the divorce process work?",
                      "What are my rights as a tenant?",
                      "How do I create a legally valid will?",
                      "What are the steps to file for bankruptcy?",
                    ].map((question, index) => (
                      <li key={index}>
                        <button
                          className="text-sm text-left w-full text-primary hover:underline"
                          onClick={() => {
                            // This would interact with the chat interface
                            console.log(`Asking: ${question}`);
                          }}
                        >
                          {question}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-card rounded-xl border border-border p-6 animate-fade-in" style={{ animationDelay: "0.2s" }}>
                  <h3 className="font-semibold mb-3">Need a Real Lawyer?</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    While our AI can provide general guidance, complex legal matters require professional assistance.
                  </p>
                  <Link to="/lawyers" className="w-full">
                    <Button variant="outline" className="w-full gap-2 group">
                      Find a Lawyer
                      <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Chatbot;
